<?php $__env->startSection('title','Match Players'); ?>
<?php $__env->startSection('content'); ?>

	<?php if(session()->has('success')): ?>
		<div class="alert alert-success" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"><?php echo e(session('success')); ?></span></div>
	<?php else: ?>
		<div class="alert alert-success" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	<?php endif; ?>
	 	
	<?php if(session()->has('error')): ?>
		<div class="alert alert-danger" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"><?php echo e(session('error')); ?></span></div>
	<?php else: ?>
		<div class="alert alert-danger" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	<?php endif; ?>
    		
  <div class="page-header row mb-15">
       <div class="col-sm-12">
        	<h2> <a href="<?php echo e(url('matches')); ?>"> << </a> Match Players (Match No - <?php echo e($records[0]->match->id.' Date: '.display_date($records[0]->match->match_date)); ?>) </h2>      
        </div>

  </div>
  
    <div class="row">
    	
    	<div class="table-responsive">
		    <table class="table align-items-center table-flush border">
				<thead class="thead-light">
					<tr>
						<th>S.No</th>
						<th>Team Name</th>
						<th>Player Name</th>
						<th>Player Pic</th>
						<th>Jersey No</th>
						<th>Country</th>
						<th  class="text-center">Actions</th>
					</tr>
				</thead>
						<tbody>
						<?php if(isset($records) && count($records) > 0): ?>
						<?php $i=1; ?>
							<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mteam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							    <?php if(isset($mteam->team->players) && count($mteam->team->players)>0): ?>
								<?php $__currentLoopData = $mteam->team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($i++); ?></td>
									<td><?php echo e($row->team->name ?? ''); ?></td>
									<td><?php echo e($row->first_name.' '.$row->last_name); ?></td>
									<td><img class="img-responsive" src="<?php echo e(url($row->image_uri)); ?>" width="100"></td>
									<td><?php echo e($row->jersey_no); ?></td>
									<td><?php echo e(country_name($row->country_id)); ?></td>
									<td class="text-center">
										<a href="javascript:void(0);" class="btn btn-primary btn-sm" onclick="loadPopup('<?php echo e(url('players/add-score/'.$row->id).'?mid='.$mteam->match_id.'&mteam_id='.$mteam->id); ?>');" >Update Player Match</a> |  
										<a href="javascript:void(0);" class="btn btn-info btn-sm" onclick="loadPopup('<?php echo e(url('players/'.$row->id)); ?>')" >View History</a>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<tr><td colspan="8" class="text-center">No data found</td></tr>
						<?php endif; ?> 
						</tbody>
					</table>
			</div>
    	
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/matches/players.blade.php ENDPATH**/ ?>