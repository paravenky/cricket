<div class="modal-header">
	<h4 class="modal-title"><?php echo e($records[0]->player->first_name ?? ''); ?> <?php echo e($records[0]->player->last_name ?? ''); ?> History</h4>
</div>

<div class="modal-body">
                   
    <div class="container">
    
		<ul class="nav nav-tabs" id="myTab" role="tablist">
		  <li class="nav-item">
		    <a class="nav-link active" id="summary" data-toggle="tab" href="#tab1" role="tab" aria-controls="summary" aria-selected="true">Summary</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" id="history" data-toggle="tab" href="#tab2" role="tab" aria-controls="history" aria-selected="false">Matches History</a>
		  </li>
		</ul>
		
		<div class="tab-content" id="myTabContent">
		
		   <div class="tab-pane fade mb-2 show active" id="tab1" role="tabpanel" aria-labelledby="summary">
		   
		   		 <div class="row">
		   		    <div class="col-sm-2"> </div>
					<div class="table-responsive col-sm-8">
					    <table class="table align-items-center table-bordered mt-2">
							<thead class="thead-light">
								<tr>
									<th colspan="6" class="text-center">Summary</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td width="50%">Total Matches</td>
									<td><?php echo e($summary->total_matches ?? 0); ?></td>
								</tr>
								<tr>
									<td>Total Runs</td>
									<td><?php echo e($summary->total_runs ?? 0); ?></td>
								</tr>
								<tr>
									<td>50's</td>
									<td><?php echo e($summary->fiftys ?? 0); ?></td>
								</tr>	
								<tr>
									<td>100's</td>
									<td><?php echo e($summary->hundreds ?? 0); ?></td>
								</tr>	
								<tr>
									<td>Total Catches</td>
									<td><?php echo e($summary->total_catches ?? 0); ?></td>
								</tr>
								<tr>
									<td>Total Wickets</td>
									<td><?php echo e($summary->total_wickets ?? 0); ?></td>
								</tr>																																						
							</tbody>
						</table>
					</div>
		      </div>
		   
		   
		   </div>
		   
		   
		   <div class="tab-pane fade mb-2" id="tab2" role="tabpanel" aria-labelledby="history">
		   
		      <div class="row">
		      
					<div class="table-responsive">
					    <table class="table align-items-center table-flush border mt-2">
							<thead class="thead-light">
								<tr>
									<th>S.No</th>
									<th>Match Date</th>
									<th>Runs</th>
									<th>Wickets</th>
									<th>Catches</th>
									<th>Overs</th>
								</tr>
							</thead>
							<tbody>
							<?php if(isset($records) && count($records) > 0): ?>
							<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e(isset($row->match->match_date) ? display_date($row->match->match_date) : ''); ?></td>
									<td><?php echo e($row->runs); ?></td>
									<td><?php echo e($row->wickets); ?></td>
									<td><?php echo e($row->catches); ?></td>
									<td><?php echo e($row->overs); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
							<tr><td colspan="6" class="text-center">No data found</td></tr>
							<?php endif; ?> 
							</tbody>
						</table>
					</div>

		      </div>
		   </div>
		</div>            

	</div>
	
</div>
    
<div class="modal-footer justify-content-center">
    <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Close</button>
</div>
<?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/players/history.blade.php ENDPATH**/ ?>