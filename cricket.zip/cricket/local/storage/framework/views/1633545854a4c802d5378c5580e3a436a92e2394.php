<form class="" action="<?php echo e(url('players')); ?>" method="post" id="create_form" name="create_form" enctype="multipart/form-data" autocomplete="off">
	<div class="modal-header">
		<h4 class="modal-title">Add Player</h4>
	</div>
 <div class="modal-body">
                     <?php echo e(csrf_field()); ?>

                     
                    <div class="row">
                    
                      <div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="team_id">Team</label>
								<div class="col-form-element col-sm-8">
								   <select name="team_id" class="form-control">
								   <option value="">Select</option>
								   <?php if(count($teams)>0): ?>
									   <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									   	<option value="<?php echo e($tm->id); ?>"><?php echo e($tm->name); ?></option>
									   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								   <?php endif; ?>
								   </select>
								</div>
							</div>
						</div>
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="first_name">First Name</label>
								<div class="col-form-element col-sm-8">
									<input type="text" name="first_name" class="form-control">
								</div>
							</div>
						</div>
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="last_name">Last Name</label>
								<div class="col-form-element col-sm-8">
									<input type="text" name="last_name" class="form-control">
								</div>
							</div>
						</div>						
                    
						<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="profile_pic">Profile Pic</label>
								<div class="col-form-element col-sm-8">
									<input type="file"  name="profile_pic" class="form-control" style="padding: 2px;" accept="image/png, image/jpeg">
								</div>
							</div>
						</div> 
						
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="jersey_no">Jersey No</label>
								<div class="col-form-element col-sm-8">
									<input type="text"  name="jersey_no" class="form-control" maxlength="4">
								</div>
							</div>
						</div>						                  
                    
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="country_id">Player Country</label>
								<div class="col-form-element col-sm-8">
								   <select name="country_id" class="form-control">
								   <option value="">Select</option>
								   <?php $__currentLoopData = country_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ckey=>$cval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								   	<option value="<?php echo e($ckey); ?>"><?php echo e($cval); ?></option>
								   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								   </select>
								</div>
							</div>
						</div>
					</div>
    </div>
    <div class="modal-footer justify-content-center">
       <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-sm btn-primary" name="save_btn" id="save_btn">Save</button>
    </div>
</form>

<script>

var create_form = $("#create_form").validate({
	ignore: "",
	rules: {
		team_id:{required:true},
		first_name:{required:true,maxlength:128},
		last_name:{required:true,maxlength:128},
		profile_pic:{required:true,accept:'jpg,jpeg,png'}
	},
	messages: {
		team_id:{required:"Select Team"},
		first_name:{required:"Enter First Name"},
		last_name:{required:"Enter Last Name"},
		profile_pic:{required:"Upload Profile Pic",accept:"Upload Images Only"}          
	}
});

$('#save_btn').click(function(e)
		{
			if($("#create_form").valid())
			{
				$("#preloader").show();
				$(this).prop('disabled', true);
				setTimeout(function() {
					$("#create_form")[0].submit();
				}, 500);
			}
		});
</script><?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/players/create.blade.php ENDPATH**/ ?>