<div class="modal-header">
		<h4 class="modal-title"><?php echo e($record->name); ?> Players</h4>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
 <div class="modal-body">
                     
     <div class="row">
           
           
        <?php if(count($record->players)>0): ?>   
            <?php $__currentLoopData = $record->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <div class="col-sm-4">
				 <div class="card mb-15">
				  <img class="card-img-top rounded" src="<?php echo e($row->image_uri); ?>" alt="<?php echo e($row->first_name); ?>">
				  <div class="card-body text-center">
				    <h5 class="card-title"><?php echo e($row->first_name.' '.$row->last_name); ?></h5>
				  </div>
				</div>
	    	</div>  
    	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="col-sm-12 text-center">No players added</div>
        <?php endif; ?>  
           

	</div>
 </div>
 
<div class="modal-footer justify-content-center">
      <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Close</button>
</div><?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/teams/players.blade.php ENDPATH**/ ?>