<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- CSRF Token -->
<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo $__env->yieldContent('title'); ?></title>


<!-- Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

<!-- Scripts -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/additional-methods.min.js')); ?>"></script>
</head>

<body>
<!-- Main content -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="<?php echo e(url('teams')); ?>">Tournament</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item <?php echo e((Request::is('teams*')) ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(url('teams')); ?>">Teams</a></li>
      <li class="nav-item <?php echo e((Request::is('players*')) ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(url('players')); ?>">Players</a></li>
	  <li class="nav-item <?php echo e((Request::is('matches*')) ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(url('matches')); ?>">Matches</a></li>
    </ul>

  </div>
</nav>

<div class="container">

	<div class="preloader" id="preloader">
		<img src="<?php echo e(url('assets/img/loading.gif')); ?>" alt="Loading...">
	</div>
	
	<?php echo $__env->yieldContent('content'); ?>


	<div class="modal" id="popup_modal" tabindex="-1" >
	    <div class="modal-dialog modal-lg" role="document">
	        <div class="modal-content" id="popup_content">
	           
	        </div>
	    </div>
	</div>

</div>

<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
</body>

</html><?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/app.blade.php ENDPATH**/ ?>