<form class="" action="<?php echo e(url('matches/update-teaminfo')); ?>" method="post" id="create_form" name="create_form" autocomplete="off">
	<div class="modal-header">
		<h4 class="modal-title">Update Match Teams Info (Match No - <?php echo e($record->id.' Date: '.display_date($record->match_date)); ?>)</h4>
	</div>
 <div class="modal-body">
                     <?php echo e(csrf_field()); ?>

                     
                   <div class="row">
                   
                        <div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="status_id">Match Status</label>
								<div class="col-form-element col-sm-8">
								   <select name="status_id" class="form-control">
									   <?php $__currentLoopData = match_status_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									   	<option value="<?php echo e($key); ?>" <?php echo e($key==$record->match_status ? 'selected=selected' : ''); ?>><?php echo e($val); ?></option>
									   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								   </select>
								</div>
							</div>
						</div>
                   
                   <?php if(count($record->matchTeams)>0): ?> 
                   <?php $__currentLoopData = $record->matchTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="team_id"><?php echo e($trow->team->name ?? ''); ?></label>
								<div class="col-form-element col-sm-4">
								   <select name="team_status_<?php echo e($trow->id); ?>" class="form-control" width="40%">
									   <?php $__currentLoopData = team_status_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									   	<option value="<?php echo e($key); ?>" <?php echo e($key==$trow->team_status ? 'selected=selected' : ''); ?>><?php echo e($val); ?></option>
									   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								   </select>
								 </div>
								 <div class="col-form-element col-sm-4">  
								   <input type="text" name="points_<?php echo e($trow->id); ?>" value="<?php echo e($trow->match_points); ?>" placeholder="Points" class="form-control" width="40%">
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<input type="hidden" name="mt_ids" value="<?php echo e(implode(',',$record->matchTeams->pluck('id')->toArray())); ?>">
					<input type="hidden" name="mid" value="<?php echo e($record->id); ?>">
					<?php endif; ?>
						
					</div>
    </div>
    <div class="modal-footer justify-content-center">
       <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-sm btn-primary" name="save_btn" id="save_btn">Update</button>
    </div>
</form>

<script>

var create_form = $("#create_form").validate({
	ignore: "",
	rules: {
		team_id:{required:true},
		first_name:{required:true,maxlength:128},
		last_name:{required:true,maxlength:128},
		profile_pic:{required:true,accept:'jpg,jpeg,png'}
	},
	messages: {
		team_id:{required:"Select Team"},
		first_name:{required:"Enter First Name"},
		last_name:{required:"Enter Last Name"},
		profile_pic:{required:"Upload Profile Pic",accept:"Upload Images Only"}          
	}
});

$('#save_btn').click(function(e)
		{
			if($("#create_form").valid())
			{
				$("#preloader").show();
				$(this).prop('disabled', true);
				setTimeout(function() {
					$("#create_form")[0].submit();
				}, 500);
			}
		});
</script><?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/matches/change-teaminfo.blade.php ENDPATH**/ ?>