<?php $__env->startSection('title','Matches'); ?>
<?php $__env->startSection('content'); ?>

	<?php if(session()->has('success')): ?>
		<div class="alert alert-success" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"><?php echo e(session('success')); ?></span></div>
	<?php else: ?>
		<div class="alert alert-success" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	<?php endif; ?>
	 	
	<?php if(session()->has('error')): ?>
		<div class="alert alert-danger" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"><?php echo e(session('error')); ?></span></div>
	<?php else: ?>
		<div class="alert alert-danger" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	<?php endif; ?>
    		
  <div class="page-header row mb-15">
       <div class="col-sm-6">
        	<h1>Matches</h1>      
        </div>
    	<div class="col-sm-6 text-right mt-15">
    	     <button class="btn-sm btn btn-primary" onclick="loadPopup('<?php echo e(url('teams/points')); ?>')">Teams Points</button>
             <button class="btn-sm btn btn-primary" id="gen_matches">Generate Matches</button>
    	</div>
  </div>
  
  <form class="" action="<?php echo e(url('matches/generate')); ?>" method="post" id="generate_form" >
  	 <?php echo e(csrf_field()); ?>

  </form>
  
    <div class="row">
    	<?php echo $__env->make('matches.dtable',$records, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<script>
$('#gen_matches').click(function(e){
	$("#preloader").show();
	$(this).prop('disabled', true);
	setTimeout(function() {
		$("#generate_form")[0].submit();
	}, 500);	
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/matches/index.blade.php ENDPATH**/ ?>