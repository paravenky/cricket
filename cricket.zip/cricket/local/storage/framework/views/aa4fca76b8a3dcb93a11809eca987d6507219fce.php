<div class="table-responsive">
    <table class="table align-items-center table-flush border">
				<thead class="thead-light">
					<tr>
						<th>S.No</th>
						<th>Match</th>
						<th>Match Date</th>
						<th>Match Status</th>
						<th>Result</th>
						<th class="text-center">Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php if(isset($records) && count($records) > 0): ?>
				<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($loop->iteration); ?></td>
						<td><?php echo e(isset($row->matchTeams[0]->team->name) ? $row->matchTeams[0]->team->name : ''); ?> Vs <?php echo e(isset($row->matchTeams[1]->team->name) ? $row->matchTeams[1]->team->name : ''); ?></td>
						<td><?php echo e(display_date($row->match_date)); ?></td>
						<td><a href="javascript:void(0);" onclick="loadPopup('<?php echo e(url('matches/change-status/'.$row->id.'/'.$row->match_status)); ?>')" title="Change Status"><?php echo e(match_status_name($row->match_status)); ?></a></td>
						<td>
						<?php 
						$sts_name ='';
						$team_sts_arr = $row->matchTeams->pluck('team_status')->toArray();
						if(in_array(1,$team_sts_arr)){
							foreach($row->matchTeams as $tm){
								if($tm->team_status==1){
								$sts_name = isset($tm->team->name) ? $tm->team->name.' Won ' : '';
								break;
								}
							}
								
						} else if(in_array(3,$team_sts_arr)){
							$sts_name = 'Match Tie';
						} else {
							$sts_name = 'Not Started';
						}
						?>
						<label class="badge badge-info"><?php echo e($sts_name); ?></label>
						</td>
						<td class="text-center">
						<a href="javascript:void(0);" class="btn btn-sm btn-primary mb-2" onclick="loadPopup('<?php echo e(url('matches/change-teaminfo/'.$row->id)); ?>')" >Update Team Info</a> <br> 
						<a class="btn btn-sm btn-info" href="<?php echo e(url('matches/players/'.$row->id)); ?>" target="_blank">Match Players</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
				<tr><td colspan="6" class="text-center">No data found</td></tr>
				<?php endif; ?> 
				</tbody>
			</table>
</div>
<?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/matches/dtable.blade.php ENDPATH**/ ?>