<div class="modal-header">
		<h4 class="modal-title">Team Matches</h4>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
 <div class="modal-body">
                     
     <div class="row">
           
<div class="table-responsive col-sm-12">
    <table class="table align-items-center table-flush border">
				<thead class="thead-light">
					<tr>
						<th>S.No</th>
						<th>Match</th>
						<th>Match Date</th>
						<th>Match Status</th>
					</tr>
				</thead>
				<tbody>
				<?php if(isset($records) && count($records) > 0): ?>
				<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($loop->iteration); ?></td>
						<td><?php echo e(isset($row->matchTeams[0]->team->name) ? $row->matchTeams[0]->team->name : ''); ?> Vs <?php echo e(isset($row->matchTeams[1]->team->name) ? $row->matchTeams[1]->team->name : ''); ?></td>
						<td><?php echo e(display_date($row->match_date)); ?></td>
						<td><a href="javascript:void(0);" ><?php echo e(match_status_name($row->match_status)); ?></a></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
				<tr><td colspan="4" class="text-center">No data found</td></tr>
				<?php endif; ?> 
				</tbody>
			</table>
</div>

	</div>
 </div>
 
<div class="modal-footer justify-content-center">
      <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Close</button>
</div><?php /**PATH E:\xampp\htdocs\cricket\local\resources\views/teams/matches.blade.php ENDPATH**/ ?>