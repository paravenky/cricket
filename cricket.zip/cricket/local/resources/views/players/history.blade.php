<div class="modal-header">
	<h4 class="modal-title">{{ $records[0]->player->first_name ?? '' }} {{ $records[0]->player->last_name ?? '' }} History</h4>
</div>

<div class="modal-body">
                   
    <div class="container">
    
		<ul class="nav nav-tabs" id="myTab" role="tablist">
		  <li class="nav-item">
		    <a class="nav-link active" id="summary" data-toggle="tab" href="#tab1" role="tab" aria-controls="summary" aria-selected="true">Summary</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" id="history" data-toggle="tab" href="#tab2" role="tab" aria-controls="history" aria-selected="false">Matches History</a>
		  </li>
		</ul>
		
		<div class="tab-content" id="myTabContent">
		
		   <div class="tab-pane fade mb-2 show active" id="tab1" role="tabpanel" aria-labelledby="summary">
		   
		   		 <div class="row">
		   		    <div class="col-sm-2"> </div>
					<div class="table-responsive col-sm-8">
					    <table class="table align-items-center table-bordered mt-2">
							<thead class="thead-light">
								<tr>
									<th colspan="6" class="text-center">Summary</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td width="50%">Total Matches</td>
									<td>{{ $summary->total_matches ?? 0 }}</td>
								</tr>
								<tr>
									<td>Total Runs</td>
									<td>{{ $summary->total_runs ?? 0 }}</td>
								</tr>
								<tr>
									<td>50's</td>
									<td>{{ $summary->fiftys ?? 0 }}</td>
								</tr>	
								<tr>
									<td>100's</td>
									<td>{{ $summary->hundreds ?? 0 }}</td>
								</tr>	
								<tr>
									<td>Total Catches</td>
									<td>{{ $summary->total_catches ?? 0 }}</td>
								</tr>
								<tr>
									<td>Total Wickets</td>
									<td>{{ $summary->total_wickets ?? 0 }}</td>
								</tr>																																						
							</tbody>
						</table>
					</div>
		      </div>
		   
		   
		   </div>
		   
		   
		   <div class="tab-pane fade mb-2" id="tab2" role="tabpanel" aria-labelledby="history">
		   
		      <div class="row">
		      
					<div class="table-responsive">
					    <table class="table align-items-center table-flush border mt-2">
							<thead class="thead-light">
								<tr>
									<th>S.No</th>
									<th>Match Date</th>
									<th>Runs</th>
									<th>Wickets</th>
									<th>Catches</th>
									<th>Overs</th>
								</tr>
							</thead>
							<tbody>
							@if(isset($records) && count($records) > 0)
							@foreach($records as $row)
								<tr>
									<td>{{ $loop->iteration }}</td>
									<td>{{ isset($row->match->match_date) ? display_date($row->match->match_date) : '' }}</td>
									<td>{{ $row->runs }}</td>
									<td>{{ $row->wickets }}</td>
									<td>{{ $row->catches }}</td>
									<td>{{ $row->overs }}</td>
								</tr>
							@endforeach
							@else
							<tr><td colspan="6" class="text-center">No data found</td></tr>
							@endif 
							</tbody>
						</table>
					</div>

		      </div>
		   </div>
		</div>            

	</div>
	
</div>
    
<div class="modal-footer justify-content-center">
    <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Close</button>
</div>
