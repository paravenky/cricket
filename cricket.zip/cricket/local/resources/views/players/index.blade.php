@extends('app')
@section('title','Players')
@section('content')

	@if(session()->has('success'))
		<div class="alert alert-success" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result">{{ session('success') }}</span></div>
	@else
		<div class="alert alert-success" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	@endif
	 	
	@if(session()->has('error'))
		<div class="alert alert-danger" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result">{{ session('error') }}</span></div>
	@else
		<div class="alert alert-danger" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	@endif
    		
  <div class="page-header row mb-15">
       <div class="col-sm-6">
        	<h1>Players</h1>      
        </div>
    	<div class="col-sm-6 text-right mt-15">
             <button class="btn-sm btn btn-primary" onclick="loadPopup('{{ url('players/create') }}')">Add Player</button>
    	</div>
  </div>
  
    <div class="row">
    	@include('players.dtable',$records)
    </div>

@endsection