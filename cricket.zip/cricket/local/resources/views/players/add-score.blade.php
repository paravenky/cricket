<form class="" action="{{ url('players/update-score') }}" method="post" id="create_form" name="create_form" autocomplete="off">
	<div class="modal-header">
		<h4 class="modal-title">Add Match Score</h4>
	</div>
 <div class="modal-body">
                     {{ csrf_field() }}
                     
                    <div class="row">
                    
                    <input type="hidden" name="player_id" value="{{ $record->id }}">
                    <input type="hidden" name="match_id" value="{{ $data['mid'] }}">
                    <input type="hidden" name="mteam_id" value="{{ $data['mteam_id']  }}">
                    
                    <div class="col-sm-10 mb-2">
                    <h6 class="text-center">{{ $match->matchTeams[0]->team->name ?? '' }} Vs {{ $match->matchTeams[1]->team->name ?? '' }}</h6>
                    </div>
                    
                      <div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right"">Team Name</label>
								<div class="col-form-element col-sm-8">
								   <input type="text"  class="form-control" value="{{ $record->team->name ?? '' }}" readonly>
								</div>
							</div>
						</div>
                       <div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right"">Player Name</label>
								<div class="col-form-element col-sm-8">
								   <input type="text"  class="form-control" value="{{ $record->first_name.' '.$record->last_name }}" readonly>
								</div>
							</div>
						</div>						
						
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="runs">Runs</label>
								<div class="col-form-element col-sm-8">
									<input type="text" name="runs" class="form-control" value="{{ $record->runs ?? '' }}" >
								</div>
							</div>
						</div>
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="wickets">Wickets</label>
								<div class="col-form-element col-sm-8">
									<input type="text" name="wickets" class="form-control" value="{{ $record->wickets ?? '' }}">
								</div>
							</div>
						</div>	
						<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="catches">Catches</label>
								<div class="col-form-element col-sm-8">
									<input type="text" name="catches" class="form-control" value="{{ $record->catches ?? '' }}">
								</div>
							</div>
						</div>	
						<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="overs">Overs</label>
								<div class="col-form-element col-sm-8">
									<input type="text" name="overs" class="form-control" value="{{ $record->overs ?? '' }}">
								</div>
							</div>
						</div>	

					</div>
    </div>
    <div class="modal-footer justify-content-center">
       <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-sm btn-primary" name="save_btn" id="save_btn">Save</button>
    </div>
</form>

<script>

var create_form = $("#create_form").validate({
	ignore: "",
	rules: {
		runs:{required:true,number:true},
		wickets:{number:true},
		catches:{number:true},
		overs:{number:true}
	},
	messages: {
		runs:{required:"Enter Runs"},
		}
});

$('#save_btn').click(function(e)
		{
			if($("#create_form").valid())
			{
				$("#preloader").show();
				$(this).prop('disabled', true);
				setTimeout(function() {
					$("#create_form")[0].submit();
				}, 500);
			}
		});
</script>