<div class="table-responsive">
    <input type="hidden" id="count" value="{{ $records->total() }}">
    <table class="table align-items-center table-flush border">
				<thead class="thead-light">
					<tr>
						<th>S.No</th>
						<th>Team Name</th>
						<th>Player Name</th>
						<th>Player Pic</th>
						<th>Jersey No</th>
						<th>Country</th>
						<th>Created Date</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
				@if(isset($records) && count($records) > 0)
				 	<?php 
				 	    $per_page = $records->perPage(); 
				 	    $skipped = ($records->currentPage() * $per_page) - $per_page; 
					?> 
				@foreach($records as $row)
					<tr>
						<td>{{ $loop->iteration+$skipped }}</td>
						<td>{{ isset($row->team->name) ? $row->team->name : '' }}</td>
						<td>{{ $row->first_name.' '.$row->last_name }}</td>
						<td><img class="img-responsive" src="{{ url($row->image_uri) }}" width="100"></td>
						<td>{{ $row->jersey_no }}</td>
						<td>{{ country_name($row->country_id) }}</td>
						<td>{{ display_date($row->created_at) }}</td>
						<td><a href="javascript:void(0);" onclick="loadPopup('{{ url('players/'.$row->id) }}')" >View History</a></td>
					</tr>
				@endforeach
				@else
				<tr><td colspan="8" class="text-center">No data found</td></tr>
				@endif 
				</tbody>
			</table>
</div>
<div class="pagination-block">
	<nav class="d-flex justify-content-between">
    	<ul>
    	    {{ $records->links() }}	
     	</ul>
  </nav>
</div>


