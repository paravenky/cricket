<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- CSRF Token -->
<meta name="csrf_token" content="{{ csrf_token() }}">

<title>@yield('title')</title>


<!-- Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700">

<link rel="stylesheet" href="{{ asset('assets/css/app.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">

<!-- Scripts -->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/js/popper.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('assets/js/additional-methods.min.js') }}"></script>
</head>

<body>
<!-- Main content -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="{{ url('teams') }}">Tournament</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item {{ (Request::is('teams*')) ? 'active' : '' }}"><a class="nav-link" href="{{ url('teams') }}">Teams</a></li>
      <li class="nav-item {{ (Request::is('players*')) ? 'active' : '' }}"><a class="nav-link" href="{{ url('players') }}">Players</a></li>
	  <li class="nav-item {{ (Request::is('matches*')) ? 'active' : '' }}"><a class="nav-link" href="{{ url('matches') }}">Matches</a></li>
    </ul>

  </div>
</nav>

<div class="container">

	<div class="preloader" id="preloader">
		<img src="{{ url('assets/img/loading.gif') }}" alt="Loading...">
	</div>
	
	@yield('content')


	<div class="modal" id="popup_modal" tabindex="-1" >
	    <div class="modal-dialog modal-lg" role="document">
	        <div class="modal-content" id="popup_content">
	           
	        </div>
	    </div>
	</div>

</div>

<script src="{{ asset('assets/js/app.js') }}"></script>
</body>

</html>