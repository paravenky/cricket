<div class="table-responsive">
    <input type="hidden" id="count" value="{{ $records->total() }}">
    <table class="table align-items-center table-flush border">
				<thead class="thead-light">
					<tr>
						<th>S.No</th>
						<th>Album</th>
						<th>Job Name</th>
						<th>Created Date</th>
						<th>Job Images</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
				@if(isset($records) && count($records) > 0)
				 	<?php 
				 	    $per_page = $records->perPage(); 
				 	    $skipped = ($records->currentPage() * $per_page) - $per_page; 
					?> 
				<input type="hidden" name="curpage" id="curpage" value="{{ $records->currentPage() }}">
				@foreach($records as $row)
					<tr>
						<td><input type="checkbox" name="jobid" class="chkbox" value="{{ $row->id }}" >{{ $loop->iteration }}</td>
						<td>{{ isset($row->album->name) ? $row->album->name : '' }}</td>
						<td>{{ $row->name }}</td>
						<td>{{ $row->created_at }}</td>
						<td><a href="javascript:void(0);" onclick="loadJobImages('{{ url('job-images?jid='.$row->id) }}')" >{{ $row->imgcount() }}</a>
						<td><a href="javascript:void(0);" onclick="loadPopup('{{ url('jobs/'.$row->id.'/edit') }}')" >Edit</a></td>
					</tr>
				@endforeach
				@else
				<tr><td colspan="5" class="text-center">No data found</td></tr>
				@endif 
				</tbody>
			</table>
</div>
<div class="pagination-block">
	<nav class="d-flex justify-content-between">
    	<ul>
    	    {{ $records->links() }}	
     	</ul>
  </nav>
</div>


