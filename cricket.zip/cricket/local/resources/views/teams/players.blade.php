<div class="modal-header">
		<h4 class="modal-title">{{ $record->name }} Players</h4>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
 <div class="modal-body">
                     
     <div class="row">
           
           
        @if(count($record->players)>0)   
            @foreach($record->players as $row)
	        <div class="col-sm-4">
				 <div class="card mb-15">
				  <img class="card-img-top rounded" src="{{ $row->image_uri }}" alt="{{ $row->first_name }}">
				  <div class="card-body text-center">
				    <h5 class="card-title">{{ $row->first_name.' '.$row->last_name }}</h5>
				  </div>
				</div>
	    	</div>  
    	    @endforeach
        @else
        <div class="col-sm-12 text-center">No players added</div>
        @endif  
           

	</div>
 </div>
 
<div class="modal-footer justify-content-center">
      <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Close</button>
</div>