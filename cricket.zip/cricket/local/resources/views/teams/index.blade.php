@extends('app')
@section('title','Teams')
@section('content')

	@if(session()->has('success'))
		<div class="alert alert-success" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result">{{ session('success') }}</span></div>
	@else
		<div class="alert alert-success" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	@endif
	 	
	@if(session()->has('error'))
		<div class="alert alert-danger" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result">{{ session('error') }}</span></div>
	@else
		<div class="alert alert-danger" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	@endif
    		
  <div class="page-header row mb-15">
       <div class="col-sm-6">
        	<h1>Teams</h1>      
        </div>
    	<div class="col-sm-6 text-right mt-15">
    	     <button class="btn-sm btn btn-primary" onclick="loadPopup('{{ url('teams/points') }}')">Teams Points</button>
             <button class="btn-sm btn btn-primary" onclick="loadPopup('{{ url('teams/create') }}')">Create Team</button>
    	</div>
  </div>
  
    <div class="row">
    	
    	@if(count($records)>0)
    	@foreach($records as $row)
    	<div class="col-sm-3">
    	
			 <div class="card mb-15">
			  <img class="card-img-top rounded" src="{{ $row->logo_uri }}" alt="{{ $row->name }}">
			  <div class="card-body text-center">
			    <h5 class="card-title">{{ $row->name }}</h5>
			    <h6 class="card-subtitle mb-3 text-muted">Club State: {{ state_name($row->club_state_id) }}</h6>
			    <a href="javascript:void(0);" onclick="loadPopup('{{ url('teams/matches/'.$row->id) }}')" class="btn btn-primary btn-sm">Matches</a>
			    <a href="javascript:void(0);" onclick="loadPopup('{{ url('teams/players/'.$row->id) }}')" class="btn btn-primary btn-sm">Players ({{ count($row->players) }})</a>
			  </div>
			</div>
    	</div>
    	@endforeach
    	@else
    	<div class="col-sm-12 text-center"> No Teams Available</div>
    	@endif
		
    </div>

@endsection