<form class="" action="{{ url('teams') }}" method="post" id="create_form" name="create_form" enctype="multipart/form-data" autocomplete="off">
	<div class="modal-header">
		<h4 class="modal-title">Create Team</h4>
	</div>
 <div class="modal-body">
                     {{ csrf_field() }}
                     
                    <div class="row">
                    
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="team_name">Team Name</label>
								<div class="col-form-element col-sm-8">
									<input type="text" name="team_name" class="form-control">
								</div>
							</div>
						</div>
                    
						<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="team_logo">Team Logo</label>
								<div class="col-form-element col-sm-8">
									<input type="file"  name="team_logo" class="form-control" style="padding: 2px;" accept="image/png, image/jpeg">
								</div>
							</div>
						</div> 
						
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="short_name">Short Name</label>
								<div class="col-form-element col-sm-8">
									<input type="text"  name="short_name" class="form-control" maxlength="4">
								</div>
							</div>
						</div>						                  
                    
                    	<div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="state_id">Team State</label>
								<div class="col-form-element col-sm-8">
								   <select name="state_id" class="form-control">
								   <option value="">Select</option>
								   @foreach(states_list() as $skey=>$sval)
								   	<option value="{{ $skey }}">{{ $sval }}</option>
								   @endforeach
								   </select>
								</div>
							</div>
						</div>
					</div>
    </div>
    <div class="modal-footer justify-content-center">
       <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-sm btn-primary" name="save_btn" id="save_btn">Save</button>
    </div>
</form>

<script>

var create_form = $("#create_form").validate({
	ignore: "",
	rules: {
		team_name:{required:true,maxlength:128},
		team_logo:{required:true,accept:'jpg,jpeg,png'}
	},
	messages: {
		team_name:{required:"Enter Team Name"},
		team_logo:{required:"Upload Team Logo",accept:"Upload Images Only"}          
	}
});

$('#save_btn').click(function(e)
		{
			if($("#create_form").valid())
			{
				$("#preloader").show();
				$(this).prop('disabled', true);
				setTimeout(function() {
					$("#create_form")[0].submit();
				}, 500);
			}
		});
</script>