<div class="modal-header">
		<h4 class="modal-title">Teams Points</h4>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
 <div class="modal-body">
                     
     <div class="row">
           
<div class="table-responsive col-sm-12">
    <table class="table align-items-center table-flush border">
				<thead class="thead-light">
					<tr>
						<th>S.No</th>
						<th>Team Name</th>
						<th>Total Matches</th>
						<th>Played</th>
						<th>Points</th>
					</tr>
				</thead>
				<tbody>
				@if(isset($records) && count($records) > 0)
				@foreach($records as $row)
					<tr>
						<td>{{ $loop->iteration }}</td>
						<td>{{ $row->team->name ?? '' }}</td>
						<td>{{ $row->matches }}</td>
						<td>{{ $row->played }}</td>
						<td>{{ $row->points }}</td>
					</tr>
				@endforeach
				@else
				<tr><td colspan="5" class="text-center">No data found</td></tr>
				@endif 
				</tbody>
			</table>
</div>

	</div>
 </div>
 
<div class="modal-footer justify-content-center">
      <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Close</button>
</div>