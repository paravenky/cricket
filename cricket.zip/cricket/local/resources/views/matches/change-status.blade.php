<form class="" action="{{ url('matches/update-status/'.$mid) }}" method="post" id="update_form" name="update_form"  autocomplete="off">
	<div class="modal-header">
		<h4 class="modal-title">Change Match Status</h4>
	</div>
 <div class="modal-body">
                     {{ csrf_field() }}
                     
                    <div class="row">
                    
                      <div class="col-sm-8">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="status_id">Match Status</label>
								<div class="col-form-element col-sm-8">
								   <select name="status_id" class="form-control">
									   @foreach(match_status_list() as $key=>$val)
									   	<option value="{{ $key }}" {{ $key==$sid ? 'selected=selected' : '' }}>{{ $val }}</option>
									   @endforeach
								   </select>
								</div>
							</div>
						</div>
						<input type="hidden" name="old_status_id" value="{{ $sid }}">

					</div>
    </div>
    <div class="modal-footer justify-content-center">
       <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-sm btn-primary" name="save_btn" id="save_btn">Update</button>
    </div>
</form>

<script>

var update_form = $("#update_form").validate({
	ignore: "",
	rules: {
		status_id:{required:true}
	},
	messages: {
		status_id:{required:"Select Status"}    
	}
});

$('#save_btn').click(function(e){
	if($("#update_form").valid())
	{
		$("#preloader").show();
		$(this).prop('disabled', true);
		setTimeout(function() {
			$("#update_form")[0].submit();
		}, 500);
	}
});
</script>