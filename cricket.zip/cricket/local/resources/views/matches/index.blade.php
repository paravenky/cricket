@extends('app')
@section('title','Matches')
@section('content')

	@if(session()->has('success'))
		<div class="alert alert-success" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result">{{ session('success') }}</span></div>
	@else
		<div class="alert alert-success" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	@endif
	 	
	@if(session()->has('error'))
		<div class="alert alert-danger" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result">{{ session('error') }}</span></div>
	@else
		<div class="alert alert-danger" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	@endif
    		
  <div class="page-header row mb-15">
       <div class="col-sm-6">
        	<h1>Matches</h1>      
        </div>
    	<div class="col-sm-6 text-right mt-15">
    	     <button class="btn-sm btn btn-primary" onclick="loadPopup('{{ url('teams/points') }}')">Teams Points</button>
             <button class="btn-sm btn btn-primary" id="gen_matches">Generate Matches</button>
    	</div>
  </div>
  
  <form class="" action="{{ url('matches/generate') }}" method="post" id="generate_form" >
  	 {{ csrf_field() }}
  </form>
  
    <div class="row">
    	@include('matches.dtable',$records)
    </div>

<script>
$('#gen_matches').click(function(e){
	$("#preloader").show();
	$(this).prop('disabled', true);
	setTimeout(function() {
		$("#generate_form")[0].submit();
	}, 500);	
});
</script>
@endsection