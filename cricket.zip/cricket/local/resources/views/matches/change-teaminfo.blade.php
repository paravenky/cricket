<form class="" action="{{ url('matches/update-teaminfo') }}" method="post" id="create_form" name="create_form" autocomplete="off">
	<div class="modal-header">
		<h4 class="modal-title">Update Match Teams Info (Match No - {{ $record->id.' Date: '.display_date($record->match_date) }})</h4>
	</div>
 <div class="modal-body">
                     {{ csrf_field() }}
                     
                   <div class="row">
                   
                        <div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="status_id">Match Status</label>
								<div class="col-form-element col-sm-8">
								   <select name="status_id" class="form-control">
									   @foreach(match_status_list() as $key=>$val)
									   	<option value="{{ $key }}" {{ $key==$record->match_status ? 'selected=selected' : '' }}>{{ $val }}</option>
									   @endforeach
								   </select>
								</div>
							</div>
						</div>
                   
                   @if(count($record->matchTeams)>0) 
                   @foreach($record->matchTeams as $trow)
                      <div class="col-sm-10">
							<div class="form-group row">
								<label class="col-form-label col-sm-4 text-right" for="team_id">{{ $trow->team->name ?? '' }}</label>
								<div class="col-form-element col-sm-4">
								   <select name="team_status_{{ $trow->id }}" class="form-control" width="40%">
									   @foreach(team_status_list() as $key=>$val)
									   	<option value="{{ $key }}" {{ $key==$trow->team_status ? 'selected=selected' : '' }}>{{ $val }}</option>
									   @endforeach
								   </select>
								 </div>
								 <div class="col-form-element col-sm-4">  
								   <input type="text" name="points_{{ $trow->id }}" value="{{ $trow->match_points }}" placeholder="Points" class="form-control" width="40%">
								</div>
							</div>
						</div>
					@endforeach
					<input type="hidden" name="mt_ids" value="{{ implode(',',$record->matchTeams->pluck('id')->toArray()) }}">
					<input type="hidden" name="mid" value="{{ $record->id }}">
					@endif
						
					</div>
    </div>
    <div class="modal-footer justify-content-center">
       <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-sm btn-primary" name="save_btn" id="save_btn">Update</button>
    </div>
</form>

<script>

var create_form = $("#create_form").validate({
	ignore: "",
	rules: {
		team_id:{required:true},
		first_name:{required:true,maxlength:128},
		last_name:{required:true,maxlength:128},
		profile_pic:{required:true,accept:'jpg,jpeg,png'}
	},
	messages: {
		team_id:{required:"Select Team"},
		first_name:{required:"Enter First Name"},
		last_name:{required:"Enter Last Name"},
		profile_pic:{required:"Upload Profile Pic",accept:"Upload Images Only"}          
	}
});

$('#save_btn').click(function(e)
		{
			if($("#create_form").valid())
			{
				$("#preloader").show();
				$(this).prop('disabled', true);
				setTimeout(function() {
					$("#create_form")[0].submit();
				}, 500);
			}
		});
</script>