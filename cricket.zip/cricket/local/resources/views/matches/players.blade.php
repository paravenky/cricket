@extends('app')
@section('title','Match Players')
@section('content')

	@if(session()->has('success'))
		<div class="alert alert-success" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result">{{ session('success') }}</span></div>
	@else
		<div class="alert alert-success" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	@endif
	 	
	@if(session()->has('error'))
		<div class="alert alert-danger" role="alert"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result">{{ session('error') }}</span></div>
	@else
		<div class="alert alert-danger" role="alert" style="display:none"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><span class="result"></span></div>
	@endif
    		
  <div class="page-header row mb-15">
       <div class="col-sm-12">
        	<h2> <a href="{{ url('matches') }}"> << </a> Match Players (Match No - {{ $records[0]->match->id.' Date: '.display_date($records[0]->match->match_date) }}) </h2>      
        </div>

  </div>
  
    <div class="row">
    	
    	<div class="table-responsive">
		    <table class="table align-items-center table-flush border">
				<thead class="thead-light">
					<tr>
						<th>S.No</th>
						<th>Team Name</th>
						<th>Player Name</th>
						<th>Player Pic</th>
						<th>Jersey No</th>
						<th>Country</th>
						<th  class="text-center">Actions</th>
					</tr>
				</thead>
						<tbody>
						@if(isset($records) && count($records) > 0)
						<?php $i=1; ?>
							@foreach($records as $mteam)
							    @if(isset($mteam->team->players) && count($mteam->team->players)>0)
								@foreach($mteam->team->players as $row)
								<tr>
									<td>{{ $i++ }}</td>
									<td>{{ $row->team->name ?? '' }}</td>
									<td>{{ $row->first_name.' '.$row->last_name }}</td>
									<td><img class="img-responsive" src="{{ url($row->image_uri) }}" width="100"></td>
									<td>{{ $row->jersey_no }}</td>
									<td>{{ country_name($row->country_id) }}</td>
									<td class="text-center">
										<a href="javascript:void(0);" class="btn btn-primary btn-sm" onclick="loadPopup('{{ url('players/add-score/'.$row->id).'?mid='.$mteam->match_id.'&mteam_id='.$mteam->id }}');" >Update Player Match</a> |  
										<a href="javascript:void(0);" class="btn btn-info btn-sm" onclick="loadPopup('{{ url('players/'.$row->id) }}')" >View History</a>
									</td>
								</tr>
								@endforeach
								@endif
							@endforeach
						@else
						<tr><td colspan="8" class="text-center">No data found</td></tr>
						@endif 
						</tbody>
					</table>
			</div>
    	
    </div>

@endsection