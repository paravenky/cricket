<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('teams');
});


Route::get('teams/players/{id}','TeamController@players');
Route::get('teams/matches/{id}','TeamController@matches');
Route::get('teams/points','TeamController@points');
Route::resource('teams','TeamController');

Route::get('players/add-score/{id}','PlayerController@addScore');
Route::post('players/update-score','PlayerController@updateScore');
Route::resource('players','PlayerController');

Route::get('matches','MatchController@index');
Route::get('matches/change-status/{mid}/{sid}','MatchController@changeStatus');
Route::post('matches/update-status/{mid}','MatchController@updateStatus');
Route::get('matches/change-teaminfo/{mid}','MatchController@changeTeaminfo');
Route::post('matches/update-teaminfo','MatchController@updateTeaminfo');
Route::get('matches/players/{mid}','MatchController@players');
Route::post('matches/generate','MatchController@generate');
