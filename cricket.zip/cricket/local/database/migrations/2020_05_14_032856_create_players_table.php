<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlayersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('players', function (Blueprint $table) {
		    $table->increments('id');
			$table->unsignedInteger('team_id');
			$table->string('first_name',128);
			$table->string('last_name',128);
			$table->string('image_uri',255);
			$table->unsignedInteger('jersey_no')->nullable();
			$table->unsignedSmallInteger('country_id')->nullable();
			$table->timestamps();
			$table->foreign('team_id')->references('id')->on('teams')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('players');
    }
}
