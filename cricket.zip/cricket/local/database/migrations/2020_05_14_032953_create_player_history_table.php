<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlayerHistoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('player_history', function (Blueprint $table) {
            $table->increments('id');
			$table->unsignedInteger('player_id');
			$table->unsignedInteger('match_id');
			$table->unsignedInteger('team_match_id');
			$table->unsignedInteger('runs');
			$table->unsignedInteger('wickets');
			$table->unsignedInteger('catches');
			$table->unsignedInteger('overs');
            $table->timestamps();
			$table->foreign('player_id')->references('id')->on('players')->onDelete('cascade');
			$table->foreign('match_id')->references('id')->on('matches')->onDelete('cascade');
			$table->foreign('team_match_id')->references('id')->on('match_teams')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('player_history');
    }
}
