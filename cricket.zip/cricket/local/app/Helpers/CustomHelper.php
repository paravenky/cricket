<?php

if (!function_exists('states_list')) {
    function states_list(){
        return [
		1 => 'Andhra Pradesh', 
		2 => 'Delhi',
		3 => 'Gujarat', 
		4 => 'Karnataka',
		5 => 'Kerala',
		6 => 'Madhya Pradesh',
		7 => 'Maharashtra',
		8 => 'Punjab',
		9 => 'Rajasthan',
		10 => 'Tamil Nadu',
		11 => 'Telangana',
		12 => 'Uttar Pradesh',
		13 => 'West Bengal'
		];
    }
}

if (!function_exists('state_name')) {
    function state_name($key){
        if($key=='' || is_null($key) || $key==0)
            return '';
        
         return states_list()[$key];
    }
}


if (!function_exists('country_list')) {
    function country_list(){
        return [
		1 => 'Australia', 
		2 => 'Bangladesh', 
		3 => 'England',
		4 => 'India',
		5 => 'New Zealand',
		6 => 'Pakistan',
		7 => 'South Africa',
		8 => 'Sri Lanka',
		9 => 'West Indies',
		10 => 'Zimbabwe'
		];
    }
}

if (!function_exists('country_name')) {
    function country_name($key){
        if($key=='' || is_null($key) || $key==0)
            return '';
        
         return country_list()[$key];
    }
}


if (!function_exists('match_status_list')) {
	function match_status_list(){
		return [
				0 => 'Not Started',
				1 => 'In Progress',
				2 => 'Completed',
				4 => 'Drawn',
				5 => 'Cancelled'
		];
	}
}

if (!function_exists('match_status_name')) {
	function match_status_name($key){
			return match_status_list()[$key];
	}
}



if (!function_exists('team_status_list')) {
	function team_status_list(){
		return [
				0 => 'Not Played',
				1 => 'Won',
				2 => 'Lost',
				3 => 'Tie'
		];
	}
}

if (!function_exists('team_status_name')) {
	function team_status_name($key){
		if($key=='' || is_null($key))
			return '';

			return team_status_list()[$key];
	}
}




if (!function_exists('display_date')) {

	function display_date($date)
	{
		if(is_null($date) || empty($date)) {
			return '';
		}

		return date('d-m-Y', strtotime($date));
	}
}
