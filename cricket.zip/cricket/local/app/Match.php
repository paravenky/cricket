<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Match extends Model
{
	protected $table = 'matches';
	
	protected $primaryKey = 'id';
	
	protected $fillable = [
			'match_date',
			'match_status',
			'created_at',
			'updated_at'
	];
	
	public function matchTeams()
	{
		return $this->hasMany('App\MatchTeam', 'match_id', 'id');
	}
	
}
