<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlayerHistory extends Model
{
	protected $table = 'player_history';
	
	protected $primaryKey = 'id';
	
	protected $fillable = [
			'player_id',
			'match_id',
			'team_match_id',
			'runs',
			'wickets',
			'catches',
			'overs',
			'created_at',
			'updated_at'
	];
	
	
	public function player()
	{
		return $this->belongsTo('App\Player', 'player_id', 'id');
	}
	
	public function match()
	{
		return $this->belongsTo('App\Match', 'match_id', 'id');
	}
	
	public function matchtm()
	{
		return $this->belongsTo('App\MatchTeam', 'team_match_id', 'id');
	}
	
}
