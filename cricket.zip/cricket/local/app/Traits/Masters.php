<?php

namespace App\Traits;


trait Masters {

    public function getTeams()
    {
        return \App\Team::orderBy('name')->get();
    }
 
}
