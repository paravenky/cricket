<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
	protected $table = 'teams';
	
	protected $primaryKey = 'id';
	
	protected $fillable = [
			'name',
			'logo_uri',
			'short_name',
			'club_state_id',
			'created_at',
			'updated_at'
	];
	
	public static $rules = ['team_name' => 'required','team_logo'=>'required'];
	
	public static $msgs = [
			'team_name.required' => 'Enter Team Name',
			'team_logo.required'  => 'Upload Team logo'
	];
	
	public function players()
	{
		return $this->hasMany('App\Player', 'team_id', 'id');
	}
	
}
