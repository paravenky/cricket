<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MatchTeam extends Model
{
	protected $table = 'match_teams';
	
	protected $primaryKey = 'id';
	
	protected $fillable = [
			'match_id',
			'team_id',
			'team_status',
			'match_points',
			'created_at',
			'updated_at'
	   ];
	
	public function team()
	{
		return $this->belongsTo('App\Team', 'team_id', 'id');
	}
	
	public function match()
	{
		return $this->belongsTo('App\Match', 'match_id', 'id');
	}
	
}
