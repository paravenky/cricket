<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Player extends Model
{
	protected $table = 'players';
	
	protected $primaryKey = 'id';
	
	protected $fillable = [
			'team_id',
			'first_name',
			'last_name',
			'image_uri',
			'jersey_no',
			'country_id',
			'created_at',
			'updated_at'
	];
	
	public static $rules = [
			'team_id'    => 'required',
			'first_name' => 'required',
			'last_name'  =>'required',
			'profile_pic'=>'required'
	];
	
	public static $msgs = [
			'team_id.required'     => 'Enter First Name',
			'first_name.required'  => 'Enter First Name',
			'last_name.required'   => 'Upload last Name',
			'profile_pic.required' => 'Upload Profile Pic'
	];
	
	public function team()
	{
		return $this->belongsTo('App\Team', 'team_id', 'id');
	}
	
}
