<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Match;
use Illuminate\Support\Facades\Input;
use App\MatchTeam;
use Illuminate\Support\Facades\DB;
use App\Team;

class MatchController extends Controller
{
	public function index()
	{
		$records = Match::orderBy('match_date')->get();
			
		return view('matches.index',compact('records'));
	}
		
	public function changeStatus($mid,$sid)
	{
		return view('matches.change-status',compact('mid','sid'));
	}	
	
	public function updateStatus($mid)
	{
		$data = Input::all();
		$new_status = $data['status_id'];
		$old_status = $data['old_status_id'];
		
		if($new_status != $old_status)
		{
			Match::where('id',$mid)
		    ->update(['match_status'=>$new_status,'updated_at'=>date('Y-m-d H:i:s')]);
		}
		
		return redirect('matches')->with('success','Status updated successfully');
	}
	
	
	public function changeTeaminfo($mid)
	{
		$record = Match::find($mid);
		
		return view('matches.change-teaminfo',compact('record'));
	}
	
	public function updateTeaminfo()
	{
		try
		{
			$data = Input::all();
			
			$match_id   = $data['mid'];
			$mt_ids     = explode(',',$data['mt_ids']);
			
			$new_status = $data['status_id'];
	
			DB::beginTransaction();
			
			Match::where('id',$match_id)->update(['match_status'=>$new_status,'updated_at'=>date('Y-m-d H:i:s')]);
	
			foreach($mt_ids as $mt_id)
			{
				MatchTeam::where('id',$mt_id)
				->update([
						'team_status'  => $data['team_status_'.$mt_id],
						'match_points' => $data['points_'.$mt_id],
						'updated_at'   => date('Y-m-d H:i:s')
				    ]);
			}
			
			DB::commit();
			
			return redirect('matches')->with('success','Team Info updated successfully');

		} catch (\Exception $e) {
			DB::rollBack();
			return redirect()->back()->withInput($data)->with('error', "Exception: " . $e->getMessage());
		}
	}
	

	public function players($mid)
	{
		$records = MatchTeam::where('match_id',$mid)->get();
	
		return view('matches.players',compact('records'));
	}	
	
	

	public function generate()
	{
		$last_date = Match::max('match_date');
		
		$next_date = isset($last_date) ? date('Y-m-d', strtotime("+1 day", strtotime($last_date))) : date('Y-m-d', strtotime("+1 day"));
	
		$teams = Team::pluck('id')->toArray();
		
		$match_sets = [];
		for($i=0;$i<count($teams);$i++)
		{
			$matchs[$i]['team_a'] = $teams[$i];
			
			for($j=$i+1;$j<count($teams);$j++)
			{
				$matchs[$i]['team_b'] = $teams[$j];
				
				$insert_id = Match::insertGetId(['match_date'=>$next_date,'created_at'=>date('Y-m-d H:i:s')]);
				
				$match_teams = [
						['match_id'=>$insert_id,'team_id'=>$matchs[$i]['team_a'],'created_at'=>date('Y-m-d H:i:s')],
				        ['match_id'=>$insert_id,'team_id'=>$matchs[$i]['team_b'],'created_at'=>date('Y-m-d H:i:s')]
					];
				
				MatchTeam::insert($match_teams);
				unset($match_teams);
				$next_date = date('Y-m-d', strtotime("+1 day", strtotime($next_date)));
			}
		}
		
		return redirect('matches')->with('success','Matches Generated Successfully');
	}
	
}
