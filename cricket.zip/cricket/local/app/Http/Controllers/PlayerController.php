<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Player;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Traits\Masters;
use App\PlayerHistory;

class PlayerController extends Controller
{
	use Masters;
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		$records = Player::paginate(10);
		 
		return view('players.index',compact('records'));
	}
	
	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		$teams = $this->getTeams();
		
		return view('players.create',compact('teams'));
	}
	
	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(Request $request)
	{
		try
		{
			$data     = Input::all();
			$rules    = Player::$rules;
			$messages = Player::$msgs;
			 
			$validator = Validator::make($data, $rules, $messages);
			if ($validator->fails()) {
				return redirect()->back()->withInput($data)->withErrors($validator->errors());
			}
			 
			if(Input::hasFile('profile_pic'))
			{
				$file = Input::file('profile_pic');
				$ext  = strtolower($file->getClientOriginalExtension());
				 
				if(!in_array($ext,['jpeg','jpg','png'])){
					return redirect()->back()->withInput($data)->with('error', 'Upload png or jpg images only');
				}
	
				$filename  = 'Player_'.date('mdHis')."_".mt_rand(100,999).'.'.$ext;
				 
				$directory = 'uploads/players/'.date('Y');
				 
				if(!is_dir($directory))
				{
					@mkdir($directory,0777,true);
				}
				 
				$full_file = $directory.'/'.$filename;
				 
				$file->move($directory,$filename);
			}
			else
			{
				return redirect()->back()->withInput($data)->with('error', 'Upload Player pic');
			}
			 
			$store_data = [
					'team_id'       => $data['team_id'],
					'first_name'    => $data['first_name'],
					'last_name'     => $data['last_name'],
					'image_uri'     => $full_file,
					'jersey_no'     => $data['jersey_no'],
					'country_id'    => $data['country_id'],
					'created_at'    => date('Y-m-d H:i:s')
			];
			 
			Player::insert($store_data);
			 
			return redirect('players')->with('success', 'Player created successfully');
	
			 
		} catch (\Exception $e) {
			return redirect()->back()->withInput($data)->with('error', "Exception: " . $e->getMessage());
		}
	}
	
	
	public function addScore($id)
	{
		$data = Input::all();
		
		$mid = $data['mid'];
		
		$record = Player::leftJoin('player_history as ph',function($join) use($mid){
		      			  $join->on('ph.player_id','=','players.id')
		                  ->where('ph.match_id',$mid);
		                 })
		                 ->where('players.id',$id)
		                 ->select('players.*','ph.match_id','ph.runs','ph.wickets','ph.catches','ph.overs')
		                 ->first();
		                 
		$match = \App\Match::find($data['mid']);
		
		return view('players.add-score',compact('record','match','data'));
		
	}
	
	public function updateScore()
	{
		try
		{
			$data = Input::all();
			
			$check_data = [
					'player_id' =>$data['player_id'],
					'match_id'  =>$data['match_id'],
					'team_match_id' => $data['mteam_id']
			];
			
			$insert_data = [
					'runs'  => $data['runs'] ?? 0,
					'wickets'  => $data['wickets'] ?? 0,
					'catches'  => $data['catches'] ?? 0,
					'overs'  => $data['overs'] ?? 0
			];
			
			PlayerHistory::updateOrCreate($check_data , $insert_data);
			
			return redirect('matches/players/'.$data['match_id'])->with('success', 'Player Match data updated successfully');
			
		} catch (\Exception $e) {
				return redirect('matches/players/'.$data['match_id'])->with('error', "Exception: " . $e->getMessage());
		}
		
	}
	
	
	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id)
	{
		$records = PlayerHistory::where('player_id',$id)->get();
		
		$summary = PlayerHistory::where('player_id',$id)
		           ->selectRaw(" player_id,count(match_id) as total_matches, SUM(runs) as total_runs, SUM(wickets) as total_wickets,
		           		SUM(catches) as total_catches, SUM(overs) as total_overs, 
		           		SUM(CASE WHEN runs between 50 and 99 THEN 1 ELSE 0 END) as fiftys,
		           		SUM(CASE WHEN runs >=100 THEN 1 ELSE 0 END) as hundreds")
		           	->with('player')
		           ->groupBy('player_id')
		           ->first();
		
		return view('players.history',compact('records','summary'));
	}
	
	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		//
	}
	
	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function update(Request $request, $id)
	{
		//
	}
	
	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id)
	{
		//
	}
}
