<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Team;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Match;
use App\MatchTeam;

class TeamController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    	$records = Team::get();
    	
        return view('teams.index',compact('records'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    	return view('teams.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    	try
    	{
    		$data     = Input::all();
    		$rules    = Team::$rules;
    		$messages = Team::$msgs;
    	
    		$validator = Validator::make($data, $rules, $messages);
    		if ($validator->fails()) {
    			return redirect()->back()->withInput($data)->withErrors($validator->errors());
    		}
    	
    		if(Input::hasFile('team_logo'))
    		{
    			$file = Input::file('team_logo');
    			$ext  = strtolower($file->getClientOriginalExtension());
    			
    			if(!in_array($ext,['jpeg','jpg','png'])){
    				return redirect()->back()->withInput($data)->with('error', 'Upload png or jpg images only');
    			}

    			$filename  = 'Team_'.date('mdHis')."_".mt_rand(10,999).'.'.$ext;
    	
    			$directory = 'uploads/teams/'.date('Y');
    	
    			if(!is_dir($directory))
    			{
    				@mkdir($directory,0777,true);
    			}
    	
    			$full_file = $directory.'/'.$filename;
    	
    			$file->move($directory,$filename);
    		}
    		else
    		{
    			return redirect()->back()->withInput($data)->with('error', 'Upload Team logo');
    		}
    	
    		$store_data = [
    				'name'          => $data['team_name'],
    				'logo_uri'      => $full_file,
    				'short_name'    => $data['short_name'],
    				'club_state_id' => $data['state_id'],
    				'created_at'    => date('Y-m-d H:i:s')
    		];
    		 
    		Team::insert($store_data);
    		 
    		return redirect('teams')->with('success', 'Team created successfully');
    		
    	
    	} catch (\Exception $e) {
    		return redirect()->back()->withInput($data)->with('error', "Exception: " . $e->getMessage());
    	}
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
    public function players($id)
    {
    	$record = Team::find($id);
    	
    	return view('teams.players',compact('record'));
    }
    
    public function matches($id)
    {
    	$records = Match::whereRaw(" id in (select match_id from match_teams where team_id=$id )")
    	           ->orderBy('match_date')->get();
    	 
    	return view('teams.matches',compact('records'));
    }
    
    
    public function points()
    {
    	$records = MatchTeam::selectRaw("team_id,SUM(match_points) as points,count(team_id) as matches, SUM(CASE WHEN team_status>0 THEN 1 ELSE 0 END) as played")
    	           ->with('team')
    	           ->groupBy('team_id')->get();
    	
    	return view('teams.points',compact('records'));
    }
    
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
