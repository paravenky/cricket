function hidealert()
{
	$(".alert").delay(10000).slideUp(800, function() {
	    $(this).slideUp();
	});
}

function loadPopup(url)
{
	$("#preloader").show();
	$("#popup_content").html('');
	$("#popup_content").load(url,function(){
		 setTimeout(function(){
			 $("#preloader").hide();
			  $("#popup_modal").modal('show');
			 },500);
		});
}

$(window).on('load',function () {
    $('#preloader').hide();
    $("body").removeAttr("style");  
});

$(document).ready(function(){
	hidealert();
});
